import React from 'react';
import { useForm } from 'react-hook-form';
// import axios from 'axios';
import styled from '@emotion/styled';

export default function Login() {
  const {
    register,
    handleSubmit,
    formState: { isSubmitting, isDirty, errors }
  } = useForm();

  // 로그인시 처리 로직
  const onSubmit = async () => {
    // axios.post('url주소', data).then((response) => {});
  };
  return (
    <LoginBox>
      <h2>로그인</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <input
          type="email"
          name="email"
          placeholder="email"
          aria-invalid={!isDirty ? undefined : errors.email ? 'true' : 'false'}
          {...register('email', {
            required: '이메일은 필수 입력입니다.',
            pattern: {
              value: /\S+@\S+\.\S+/,
              message: '이메일 형식에 맞지 않습니다.'
            }
          })}
        />
        {errors.email && <small>{errors.email.message}</small>}
        <input
          type="password"
          name="password"
          placeholder="password"
          aria-invalid={!isDirty ? undefined : errors.password ? 'true' : 'false'}
          {...register('password', {
            required: '비밀번호는 필수 입력입니다.',
            minLength: {
              value: 8,
              message: '8자리 이상 비밀번호를 사용하세요.'
            }
          })}
        />
        {errors.password && <small role="alert">{errors.password.message}</small>}
        <button type="submit" disabled={isSubmitting}>
          로그인
        </button>
      </form>
    </LoginBox>
  );
}

// css 부분
const LoginBox = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 40rem;
  height: 25rem;
  vertical-align: middle;
  border: 1px solid black;
`;
